import { MigrationInterface, QueryRunner } from "typeorm"

export class Df1681065911535 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<void> {
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
    }

}
